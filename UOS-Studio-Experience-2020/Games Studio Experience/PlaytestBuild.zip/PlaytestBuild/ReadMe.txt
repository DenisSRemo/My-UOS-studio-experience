For this series of playtesting, the game while be recording some information about your gameplay of each level for example the amount of shots taken per level etc.

To be able to get this important information we need you to attach the file containing it after your play session.

The file will be located in the folder which contains the unity exe for the game and will be named Analytics.csv .

By sending this file back to us after your playtesting it allows us to be able to tweak levels and find out how players are playing the game.